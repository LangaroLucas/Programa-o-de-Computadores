// "class exemplo_01" declaração de classe
class exemplo_01 {
    // Método princpal da classe
    public static void main(String[] args){
        //Serve para mostrar as informações para o usuário
        System.out.println("Ola Mundo!");

        //declarar uma variável do tipo "int" chamada idade:  // \n caractere especial, serve para quebra de linha
        int idade;
        idade = 25; // declara e inicializa
        System.out.println("Eu\nComecei\nCom: " + idade);

        idade = 29; // altera o valor
        System.out.println("Agora eu tenho: " + idade);

        //declarar uma variável do tipo "String" chamada nome:
        String nome;
        nome = "Lucas";
        System.out.println("Meu nome e: " + nome);

        //declarar uma variável do tipo "boolean" chamda Status_aluno: 
        boolean Status_aluno;
        Status_aluno = true;

        //função para mudar o "True" para "Ativo"
        String situacao;
        if (Status_aluno) {

            situacao = "Ativo";
        } else {

            situacao = "Inativo";
        }
        System.out.println("A situacao do aluno e: " + situacao);

        //declarar uma variável do tipo "char" chamada periodo:
        char periodo;
        periodo = '2';
        System.out.println("Qual o periodo? " + periodo);
    }

}
