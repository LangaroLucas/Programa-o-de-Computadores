import java.util.Scanner;

//class é o padrão arquivo java
class exemplo_operadores{
    //como iniciar um arquivo java

    public static void main(String[] args){

        int A;
        int B;

        int soma;
        int subtracao;
        int multiplicacao;
        double divisao;
        double resto_divisao; //é chamado de operador módulo ou operador resto.

        Scanner s = new Scanner(System.in); //Variável para ler informações do terminal (entrada de dados)

        System.out.println("Informe os valores inteiros para:");
        System.out.print("A: ");
        A = s.nextInt();

        System.out.print("B: ");
        B = s.nextInt();

        soma = A + B;
        subtracao = A - B;
        multiplicacao = A * B;
        divisao = A / B;
        resto_divisao = A % B; 

        //exibir na tela do usuário
        System.out.println("Resultado das operacoes Aritimeticas entre A e B");
        System.out.println("A: " + A + "\nB: " + B);
        System.out.println("Soma: " + soma);
        System.out.println("Subtracao: " + subtracao);
        System.out.println("Mutiplicacao: " + multiplicacao);
        System.out.println("Divisao: " + divisao);
        System.out.println("Resto da Divisao: " + resto_divisao);

        System.out.println("Resultado das operacoes Relacionais entre A e B");
        System.out.println("A < B: " + (A<B) ); // < menor que
        System.out.println("A > B: " + (A>B) ); // > maior que
        System.out.println("A == B " + (A==B) ); // == Igual a
        System.out.println("A != B " + (A!=B) ); // != Diferente de
        System.out.println("A >= B " + (A>=B) ); //Maior ou igual a
        System.out.println("A <= B " + (A<=B) ); //Menor ou igual a

    }   

}