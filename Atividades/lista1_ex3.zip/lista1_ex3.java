public class lista1_ex3 {
   public static void main(String[] args){
    /
   }

}