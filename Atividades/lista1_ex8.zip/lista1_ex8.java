public class lista1_ex8 {
    public static void main(String[] args) {
        
    }
}
